# Weak-structure detectability under denoising-strength mismatch

Executed split: **test**; 100 clean geometry clusters. Held-out test; all sigma/a conditions and all noise repeats retained.

Shared operating points: eta=0.76, beta=0.8. Selected solely by validation macro AP across all 40 geometries, both sigma and all three a values, with 3 repeats each.

## Primary comparison

Selected TV minus proposal overall macro AP: **+0.043140**, paired geometry bootstrap percentile 95% CI **[+0.039656, +0.046707]**.

Selected TV background RMSE / noisy background RMSE: **0.197503**, geometry bootstrap 95% CI **[0.197209, 0.197789]**.

## Interpretation

(a) AP improvement with background error below noisy, supported by both intervals: **True**.

(b) Signed contrast bias closer to clean, without mean AP improvement: **False**.

(c) Comparable to fixed within the predeclared ±0.01 AP margin (entire CI inside margin): **True**. TV minus fixed = -0.000101, 95% CI [-0.000557, +0.000369]. An interval merely overlapping zero is not evidence of equivalence.

(d) Negative mean AP effect: **False**; AP CI entirely below zero: **False**; mean background error above noisy: **False**.

Secondary strata with negative mean TV-minus-proposal AP: a=1: -0.006290 [-0.008439, -0.004339], sigma=25,a=1: -0.013006 [-0.017237, -0.009144]. These exploratory intervals are not multiplicity-adjusted.

These are separately reported patterns and may coexist. Contrast recovery alone is not treated as detection improvement. Mixed or uncertain patterns remain visible in the estimates and intervals.

Clean reference macro AP: 0.912558; detector/task mismatch flag (threshold 0.7): **False**. No detector settings changed after formal configuration freeze.

Individual clean-reference geometries below the same predeclared AP threshold: 0. They remain in all applicable statistics; per-image clean AP is retained in the CSV.

## Main table by mismatch strength

| a | method | ap | background_rmse_ratio | contrast_rmse | psnr |
| --- | --- | --- | --- | --- | --- |
| 1.00000 | beta_0.2 | 0.55449 | 0.79946 | 0.00456 | 24.33359 |
| 1.00000 | clean | 0.91256 | 0.00000 | 0.00000 | inf |
| 1.00000 | fixed | 0.82561 | 0.24123 | 0.00814 | 34.70080 |
| 1.00000 | noisy | 0.42648 | 1.00000 | 0.00421 | 22.39042 |
| 1.00000 | proposal | 0.83605 | 0.01322 | 0.01006 | 52.87939 |
| 1.00000 | tv | 0.82976 | 0.19625 | 0.00847 | 36.46892 |
| 1.50000 | beta_0.2 | 0.50835 | 0.79954 | 0.00758 | 24.33234 |
| 1.50000 | clean | 0.91256 | 0.00000 | 0.00000 | inf |
| 1.50000 | fixed | 0.62460 | 0.24069 | 0.02505 | 34.63252 |
| 1.50000 | noisy | 0.42648 | 1.00000 | 0.00421 | 22.39042 |
| 1.50000 | proposal | 0.58510 | 0.01676 | 0.03284 | 47.75849 |
| 1.50000 | tv | 0.62345 | 0.19741 | 0.02643 | 36.27437 |
| 2.00000 | beta_0.2 | 0.46954 | 0.79968 | 0.01005 | 24.33030 |
| 2.00000 | clean | 0.91256 | 0.00000 | 0.00000 | inf |
| 2.00000 | fixed | 0.50052 | 0.24102 | 0.03584 | 34.50937 |
| 2.00000 | noisy | 0.42648 | 1.00000 | 0.00421 | 22.39042 |
| 2.00000 | proposal | 0.39986 | 0.02342 | 0.04711 | 44.85117 |
| 2.00000 | tv | 0.49722 | 0.19885 | 0.03781 | 36.03577 |

### AP paired intervals by a (secondary)

| stratum | reference | difference | ci_low | ci_high | n_geometries |
| --- | --- | --- | --- | --- | --- |
| a=1 | proposal | -0.00629 | -0.00844 | -0.00434 | 100 |
| a=1 | fixed | 0.00415 | 0.00329 | 0.00509 | 100 |
| a=1.5 | proposal | 0.03834 | 0.03497 | 0.04172 | 100 |
| a=1.5 | fixed | -0.00116 | -0.00157 | -0.00069 | 100 |
| a=2 | proposal | 0.09737 | 0.09009 | 0.10478 | 100 |
| a=2 | fixed | -0.00330 | -0.00370 | -0.00287 | 100 |

### Strict beta=0.2 (exploratory)

| a | ap | background_rmse_ratio | contrast_rmse | psnr |
| --- | --- | --- | --- | --- |
| 1.00000 | 0.55449 | 0.79946 | 0.00456 | 24.33359 |
| 1.50000 | 0.50835 | 0.79954 | 0.00758 | 24.33234 |
| 2.00000 | 0.46954 | 0.79968 | 0.01005 | 24.33030 |

Beta=0.2 is displayed independently of the selected beta. Its paired AP comparisons with proposal are in paired_comparisons.csv; a stricter budget is not assumed better.

## Protocol and isolation

Images are 256×256 grayscale geometries replicated to RGB. Gaussian noise is independent by RGB channel, geometry, sigma and repeat; the identical clipped float32 observation is shared across a and methods. DRUNet uses noise_map=a*sigma and the original CPU inference/preprocessing. Geometry and noise use separate seeded streams; validation/test geometries are disjoint.

Masks derive only from antialiased coverage (8× supersampling, block area averaging); AP uses coverage≥0.5 inside a common 12-pixel boundary. Per-line core/side masks exclude end caps and pixels within 8 pixels of other line support. Geometric degeneracy reasons are saved for every line; invalid line contrast is NA, while the geometry remains in AP and noise metrics. Background is more than 10 pixels from all line support. No output-dependent exclusion occurs.

Geometric line regions: 449 total, 2 invalid by the fixed pixel-count rules. See geometric_region_validity.csv. All geometries remain in the primary AP analysis.

AP, background RMSE and contrast use float64 arithmetic RGB mean. No per-image input or response normalization. Sato uses sigmas=(1,2,3), black_ridges=False, mode=reflect, cval=0; raw responses feed tie-aware, non-interpolated pixel AP, computed separately per image. RGB PSNR uses range 1; clean-reference PSNR is infinite.

Clean/masks are used for validation operating-point selection and test scoring. The controller interface accepts only f, v, beta. Global fixed eta is unconstrained by TV. All 101 fixed eta and six beta values are evaluated; test scans are diagnostic/exploratory and do not select deployed points. Ties within 1e-12 choose the smaller parameter.

Statistics first average repeats within each geometry/sigma/a, then equally average conditions within geometry. Paired differences are resampled by clean geometry with 10,000 draws and percentile 95% intervals. Pixels, repeats, sigma/a and beta are never independent bootstrap units. Strata, beta scans and fixed comparisons are secondary/exploratory; no multiplicity-adjusted claims are made.

TV uses the original RGB vector-valued zero-outward forward-difference definition, epsilon=1e-8, float64 TV, float32 endpoints/outputs and 28 bisection steps. All 10800 actual returned arrays were saved and reopened for independent audit at tolerance 1e-12; maximum signed budget residual=-1.454e-13. Non-TV scan budgets are NA because those outputs have no budget constraint.

## Figures and complete records

![Complete trade-off](test_tradeoff.png)

![Robustness](test_robustness.png)

The stars identify validation selections (preassigned values in development), not test optima. All method images share [0,1]; every detector response shares [0,0.06] for display only. Numeric scoring uses unclipped raw responses. Main example IDs were specified in the manifest before generation. contact_sheet_index.csv enumerates every geometry/noise/sigma/a case; contact_sheet/ and the PDF contain all examples.

## Actual execution environment

Python: 3.14.4 (main, Aug 20 2026, 10:41:58) [GCC 15.2.0]. Device: cpu. Packages: numpy=2.5.3, scipy=1.18.1, scikit-image=0.26.0, pandas=3.0.5, matplotlib=3.11.1, Pillow=12.3.0, torch=2.14.0+cpu.

Model: `/home/ruijie/ECTV_code-main/data/models/drunet_color.pth`. SHA256: `479abe3c5327dfd10ff54a80ec7d4098ca80752a5c9492cdff31cee430bec4b4`.

Sato runtime signature: `(image, sigmas=range(1, 10, 2), black_ridges=True, mode='reflect', cval=0)`. Seeds: `{'geometry': 2026091601, 'noise': 2026091602, 'bootstrap': 2026091603, 'torch': 2026091604}`.

Detector specification: [scikit-image Sato](https://scikit-image.org/docs/0.26.x/api/skimage.filters.html#skimage.filters.sato). Metric definition: [non-interpolated average precision](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.average_precision_score.html).

[Run commands and cache layout](../../experiments/weak_structure/README.md).

Full image caches, all per-line records, and all 1,800 contact-sheet cases are in the separately delivered complete run archive. This compact reference directory supplies selected per-sample rows and every scan point aggregated by clean geometry.
